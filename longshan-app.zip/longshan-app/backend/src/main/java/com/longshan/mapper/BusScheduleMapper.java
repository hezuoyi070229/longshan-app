package com.longshan.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.longshan.entity.BusSchedule;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface BusScheduleMapper extends BaseMapper<BusSchedule> {
}
